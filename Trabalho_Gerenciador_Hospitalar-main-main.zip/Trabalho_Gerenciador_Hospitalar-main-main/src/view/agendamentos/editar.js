document.addEventListener('DOMContentLoaded', () => {
  const API_URL = 'http://localhost:3000/api'; // Ajuste para seu backend
  const pacienteSelect = document.getElementById('paciente_id');
  const profissionalSelect = document.getElementById('profissional_id');
  const dataInput = document.getElementById('data_agendamento');
  const horaInput = document.getElementById('hora_agendamento');
  const tipoInput = document.getElementById('tipo_agendamento');
  const observacoesInput = document.getElementById('observacoes');
  const form = document.getElementById('formAgendamento');
  const statusMessage = document.getElementById('statusMessage');

  function showMessage(message, type = 'error') {
    statusMessage.textContent = message;
    statusMessage.className = `mt-4 p-3 rounded-md text-sm font-medium text-center ${
      type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
    }`;
    statusMessage.classList.remove('hidden');

    if (type === 'success') {
      setTimeout(() => {
        window.location.href = '../agendamentos/visualizarAgendamentos.html';
      }, 2000);
    }
  }

  // Carrega pacientes no select
  async function loadPacientes() {
    try {
      const res = await fetch(`${API_URL}/pacientes`);
      if (!res.ok) throw new Error(`Erro HTTP: ${res.status}`);
      const data = await res.json();
      const pacientes = data.pacientes || data || [];
      pacienteSelect.innerHTML = '<option value="">Selecione...</option>';
      pacientes.forEach(p => {
        const option = document.createElement('option');
        option.value = String(p.paciente_id); // garante string
        option.textContent = p.nome_completo || p.nome || `Paciente ${p.paciente_id}`;
        pacienteSelect.appendChild(option);
      });
    } catch (err) {
      console.error(err);
      showMessage('Erro ao carregar pacientes');
    }
  }

  // Carrega profissionais no select
  async function loadProfissionais() {
    try {
      const res = await fetch(`${API_URL}/profissionais`);
      if (!res.ok) throw new Error(`Erro HTTP: ${res.status}`);
      const data = await res.json();
      const profissionais = data.profissionais || data || [];
      profissionalSelect.innerHTML = '<option value="">Selecione...</option>';
      profissionais.forEach(p => {
        const option = document.createElement('option');
        option.value = String(p.profissional_id);
        option.textContent = p.nome_completo || p.nome || `Profissional ${p.profissional_id}`;
        profissionalSelect.appendChild(option);
      });
    } catch (err) {
      console.error(err);
      showMessage('Erro ao carregar profissionais');
    }
  }

  // Preenche o formulário com os dados do agendamento
  async function fetchAgendamento(id) {
    try {
      const res = await fetch(`${API_URL}/agendamentos/${id}`);
      if (!res.ok) throw new Error(`Erro HTTP: ${res.status}`);
      const data = await res.json();
      const agendamento = data.agendamento || data;

      pacienteSelect.value = String(agendamento.paciente_id);
      profissionalSelect.value = String(agendamento.profissional_id);
      dataInput.value = agendamento.data_agendamento?.split('T')[0] || '';
      horaInput.value = agendamento.hora_agendamento?.substring(0,5) || '';
      tipoInput.value = agendamento.tipo_agendamento || '';
      observacoesInput.value = agendamento.observacoes || '';
    } catch (err) {
      console.error(err);
      showMessage('Erro ao carregar agendamento');
    }
  }

  // Submit do formulário
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = new URLSearchParams(window.location.search);
    const id = parseInt(params.get('id'));
    const pacienteId = parseInt(pacienteSelect.value);
    const profissionalId = parseInt(profissionalSelect.value);
    const dataAgendamento = dataInput.value;
    const horaAgendamento = horaInput.value;
    const tipoAgendamento = tipoInput.value;
    const observacoes = observacoesInput.value;

    // Validações
    if (!id || isNaN(id)) return showMessage('ID do agendamento inválido!');
    if (!pacienteId || isNaN(pacienteId)) return showMessage('Selecione um paciente válido!');
    if (!profissionalId || isNaN(profissionalId)) return showMessage('Selecione um profissional válido!');
    if (!dataAgendamento) return showMessage('Informe a data do agendamento!');
    if (!horaAgendamento) return showMessage('Informe a hora do agendamento!');
    if (!tipoAgendamento.trim()) return showMessage('Informe o tipo do agendamento!');

    const updatedData = {
      paciente_id: pacienteId,
      profissional_id: profissionalId,
      data_agendamento: dataAgendamento,
      hora_agendamento: horaAgendamento.includes(':') ? horaAgendamento : horaAgendamento + ':00',
      tipo_agendamento: tipoAgendamento,
      observacoes: observacoes || null
    };

    try {
      const res = await fetch(`${API_URL}/agendamentos/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedData)
      });

      const result = await res.json();
      if (res.ok) {
        showMessage(result.message || 'Agendamento atualizado com sucesso!', 'success');
      } else {
        showMessage(result.message || result.error || `Erro ${res.status}: ${res.statusText}`);
      }
    } catch (err) {
      console.error(err);
      showMessage('Erro ao conectar com o servidor: ' + err.message);
    }
  });

  // Inicialização
  async function init() {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');

    // Carrega selects primeiro
    await loadPacientes();
    await loadProfissionais();

    // Depois preenche o formulário
    if (id) await fetchAgendamento(id);
  }

  init();
});
