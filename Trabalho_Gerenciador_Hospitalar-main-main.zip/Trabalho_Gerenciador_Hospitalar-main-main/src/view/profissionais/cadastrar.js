document.addEventListener('DOMContentLoaded', () => {
    // ===== Elementos do formulário =====
    const formProfissional = document.getElementById('FormProfissional');
    const statusMessage = document.getElementById('statusMessage');
    const cepInput = document.getElementById('cep');
    const ruaInput = document.getElementById('rua');
    const bairroInput = document.getElementById('bairro');
    const cidadeInput = document.getElementById('cidade');
    const estadoInput = document.getElementById('estado');
    const cepStatus = document.getElementById('cepStatus');

    // ===== Função para formatar CEP =====
    const formatarCep = (cep) => cep.replace(/\D/g, '');

    // ===== Função para preencher endereço =====
    const preencherEndereco = (data) => {
        if (ruaInput) ruaInput.value = data.logradouro || '';
        if (bairroInput) bairroInput.value = data.bairro || '';
        if (cidadeInput) cidadeInput.value = data.localidade || '';
        if (estadoInput) estadoInput.value = data.uf || '';
    };

    // ===== Buscar CEP na API =====
    const buscarCep = async (cep) => {
        const cepFormatado = formatarCep(cep);
        if (cepFormatado.length !== 8) {
            if (cepStatus) {
                cepStatus.textContent = 'CEP inválido.';
                cepStatus.className = 'mt-1 text-sm text-red-500';
            }
            return;
        }

        if (cepStatus) {
            cepStatus.textContent = 'Buscando CEP...';
            cepStatus.className = 'mt-1 text-sm text-blue-500';
        }

        // Limpa campos de endereço
        preencherEndereco({ logradouro: '', bairro: '', localidade: '', uf: '' });

        try {
            const resposta = await fetch(`https://viacep.com.br/ws/${cepFormatado}/json/`);
            const data = await resposta.json();

            if (data.erro) {
                if (cepStatus) {
                    cepStatus.textContent = 'CEP não encontrado.';
                    cepStatus.className = 'mt-1 text-sm text-red-500';
                }
                return;
            }

            preencherEndereco(data);
            if (cepStatus) {
                cepStatus.textContent = 'CEP encontrado com sucesso!';
                cepStatus.className = 'mt-1 text-sm text-green-500';
            }
        } catch (error) {
            console.error('Erro ao buscar CEP:', error);
            if (cepStatus) {
                cepStatus.textContent = 'Erro ao buscar CEP. Tente novamente.';
                cepStatus.className = 'mt-1 text-sm text-red-500';
            }
        }
    };

    // ===== Eventos do CEP =====
    if (cepInput) {
        // Buscar CEP quando o campo perde o foco
        cepInput.addEventListener('blur', (e) => {
            const cep = e.target.value;
            if (cep) buscarCep(cep);
        });

        // Formatar CEP enquanto digita
        cepInput.addEventListener('input', (e) => {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 5) {
                value = value.substring(0, 5) + '-' + value.substring(5, 8);
            }
            e.target.value = value;
        });
    }

    // ===== Função para mostrar mensagem de status =====
    const mostrarMensagem = (mensagem, tipo) => {
        if (!statusMessage) return;

        statusMessage.classList.remove('hidden', 'bg-red-100', 'text-red-700', 'bg-green-100', 'text-green-700');
        
        if (tipo === 'sucesso') {
            statusMessage.classList.add('bg-green-100', 'text-green-700');
        } else if (tipo === 'erro') {
            statusMessage.classList.add('bg-red-100', 'text-red-700');
        }
        
        statusMessage.textContent = mensagem;

        // Auto-ocultar mensagem de sucesso após 3 segundos
        if (tipo === 'sucesso') {
            setTimeout(() => {
                statusMessage.classList.add('hidden');
                statusMessage.textContent = '';
            }, 3000);
        }
    };

    // ===== Função para limpar formulário =====
    const limparFormulario = () => {
        if (formProfissional) {
            formProfissional.reset();
        }
        
        if (cepStatus) {
            cepStatus.textContent = '';
            cepStatus.className = 'mt-1 text-sm';
        }
    };

    // ===== Envio do formulário =====
    if (formProfissional) {
        formProfissional.addEventListener('submit', async (event) => {
            event.preventDefault();

            // Limpa mensagens anteriores
            if (statusMessage) {
                statusMessage.classList.add('hidden');
                statusMessage.textContent = '';
            }

            // Coleta dados do formulário
            const formData = new FormData(formProfissional);
            const data = {
                nomeCompleto: formData.get('name'),
                email: formData.get('email'),
                crm: formData.get('crm'),
                dataNascimento: formData.get('dob'),
                dataAdmissao: formData.get('joiningDate'),
                telefone: formData.get('phone'),
                genero: formData.get('gender'),
                especialidade: formData.get('specialty'),
                endereco: {
                    cep: formatarCep(formData.get('cep')),
                    rua: formData.get('rua'),
                    numero: formData.get('numero'),
                    bairro: formData.get('bairro'),
                    cidade: formData.get('cidade'),
                    estado: formData.get('estado')
                },
                biografia: formData.get('biography')
            };

            try {
                const response = await fetch('/api/profissionais', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });

                const result = await response.json();

                if (response.ok) {
                    mostrarMensagem(
                        result.message || 'Profissional cadastrado com sucesso!', 
                        'sucesso'
                    );
                    limparFormulario();
                    
                    // Rola para o topo do formulário
                    formProfissional.scrollIntoView({ behavior: 'smooth' });
                } else {
                    mostrarMensagem(
                        result.message || 'Erro ao cadastrar profissional.', 
                        'erro'
                    );
                }
            } catch (error) {
                console.error('Erro na requisição:', error);
                mostrarMensagem(
                    'Erro ao conectar com o servidor. Tente novamente.', 
                    'erro'
                );
            }
        });
    } else {
        console.error('Formulário com ID "FormProfissional" não encontrado.');
    }

    // ===== Validação adicional dos campos obrigatórios =====
    const validarCamposObrigatorios = () => {
        const camposObrigatorios = [
            { campo: document.getElementById('email'), nome: 'Email' },
            { campo: document.getElementById('crm'), nome: 'CRM' },
            { campo: document.getElementById('specialty'), nome: 'Especialidade' },
            { campo: document.getElementById('cep'), nome: 'CEP' },
            { campo: document.getElementById('rua'), nome: 'Rua' },
            { campo: document.getElementById('numero'), nome: 'Número' },
            { campo: document.getElementById('bairro'), nome: 'Bairro' },
            { campo: document.getElementById('cidade'), nome: 'Cidade' },
            { campo: document.getElementById('estado'), nome: 'Estado' }
        ];

        let camposVazios = [];
        
        camposObrigatorios.forEach(({ campo, nome }) => {
            if (campo && !campo.value.trim()) {
                camposVazios.push(nome);
            }
        });

        return camposVazios;
    };

    // Adiciona validação antes do envio
    if (formProfissional) {
        formProfissional.addEventListener('submit', (event) => {
            const camposVazios = validarCamposObrigatorios();
            
            if (camposVazios.length > 0) {
                event.preventDefault();
                mostrarMensagem(
                    `Por favor, preencha os seguintes campos obrigatórios: ${camposVazios.join(', ')}`, 
                    'erro'
                );
                return false;
            }
        });
    }
});