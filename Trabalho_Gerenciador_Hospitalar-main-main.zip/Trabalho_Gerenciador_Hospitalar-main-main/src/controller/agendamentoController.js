import Agendamento from '../model/agendamento.js';

class AgendamentoController {
  
  static adicionarAgendamento(req, res) {
    console.log('Dados recebidos para adicionar:', req.body);
    
    // Aceita tanto o formato snake_case quanto camelCase
    const paciente_id = req.body.paciente_id || req.body.pacienteId;
    const profissional_id = req.body.profissional_id || req.body.profissionalId;
    const data_agendamento = req.body.data_agendamento || req.body.dataAgendamento;
    const hora_agendamento = req.body.hora_agendamento || req.body.horaAgendamento;
    const tipo_agendamento = req.body.tipo_agendamento || req.body.tipoAgendamento;
    const observacoes = req.body.observacoes;

    if (!paciente_id || !profissional_id || !data_agendamento || !hora_agendamento || !tipo_agendamento) {
      return res.status(400).json({ message: 'Preencha todos os campos obrigatórios.' });
    }

    const dados = {
      paciente_id,
      profissional_id, 
      data_agendamento,
      hora_agendamento,
      tipo_agendamento,
      observacoes
    };

    Agendamento.adicionar(dados, (err, result) => {
      if (err) {
        console.error('Erro ao cadastrar agendamento:', err);
        return res.status(500).json({ message: 'Erro ao cadastrar agendamento.' });
      }
      res.status(201).json({ message: 'Agendamento cadastrado com sucesso!', agendamentoId: result.insertId });
    });
  }

  static visualizarAgendamentos(req, res) {
    Agendamento.visualizarTodos((err, results) => {
      if (err) {
        console.error('Erro ao buscar agendamentos:', err);
        return res.status(500).json({ message: 'Erro ao buscar agendamentos.' });
      }
      res.json({ agendamentos: results });
    });
  }

  static visualizarAgendamentoPorId(req, res) {
    const { id } = req.params;
    console.log('Buscando agendamento por ID:', id);
    
    Agendamento.visualizarPorId(id, (err, results) => {
      if (err) {
        console.error('Erro ao buscar agendamento:', err);
        return res.status(500).json({ message: 'Erro ao buscar agendamento.' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'Agendamento não encontrado.' });
      }
      
      console.log('Agendamento encontrado:', results[0]);
      res.json({ agendamento: results[0] });
    });
  }

  static editarAgendamento(req, res) {
    const { id } = req.params;
    console.log('Editando agendamento ID:', id);
    console.log('Dados recebidos para edição:', req.body);

    // Monta o objeto de dados no formato correto (snake_case)
    const dados = {};
    
    if (req.body.paciente_id !== undefined) dados.paciente_id = req.body.paciente_id;
    if (req.body.profissional_id !== undefined) dados.profissional_id = req.body.profissional_id;
    if (req.body.data_agendamento !== undefined) dados.data_agendamento = req.body.data_agendamento;
    if (req.body.hora_agendamento !== undefined) dados.hora_agendamento = req.body.hora_agendamento;
    if (req.body.tipo_agendamento !== undefined) dados.tipo_agendamento = req.body.tipo_agendamento;
    if (req.body.observacoes !== undefined) dados.observacoes = req.body.observacoes;

    console.log('Dados formatados para o modelo:', dados);

    if (Object.keys(dados).length === 0) {
      return res.status(400).json({ message: 'Nenhum campo válido fornecido para atualização.' });
    }

    Agendamento.editar(id, dados, (err, result) => {
      if (err) {
        console.error('Erro ao atualizar agendamento:', err);
        return res.status(500).json({ message: 'Erro ao atualizar agendamento: ' + err.message });
      }
      
      console.log('Resultado da atualização:', result);
      
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Agendamento não encontrado.' });
      }
      
      res.json({ message: 'Agendamento atualizado com sucesso!' });
    });
  }

  static deletarAgendamento(req, res) {
    const { id } = req.params;
    
    Agendamento.deletar(id, (err, result) => {
      if (err) {
        console.error('Erro ao deletar agendamento:', err);
        return res.status(500).json({ message: 'Erro ao deletar agendamento.' });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Agendamento não encontrado.' });
      }
      res.json({ message: 'Agendamento deletado com sucesso!' });
    });
  }
}

export default AgendamentoController;