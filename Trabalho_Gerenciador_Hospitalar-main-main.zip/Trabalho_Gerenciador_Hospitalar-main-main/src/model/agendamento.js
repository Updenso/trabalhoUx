import db from '../config/DBconfig.js';

class Agendamento {
  static adicionar(dados, callback) {
    const query = `
      INSERT INTO agendamento 
        (paciente_id, profissional_id, data_agendamento, hora_agendamento, tipo_agendamento, observacoes) 
      VALUES (?, ?, ?, ?, ?, ?)
    `;
    const values = [
      dados.paciente_id,
      dados.profissional_id,
      dados.data_agendamento,
      dados.hora_agendamento,
      dados.tipo_agendamento,
      dados.observacoes || null
    ];
    db.query(query, values, callback);
  }

  static visualizarTodos(callback) {
    const query = `
      SELECT 
        a.agendamento_id,
        a.paciente_id,
        p.nome_completo AS paciente_nome,
        a.profissional_id,
        prof.nome_completo AS profissional_nome,
        a.data_agendamento,
        a.hora_agendamento,
        a.tipo_agendamento,
        a.observacoes
      FROM agendamento a
      LEFT JOIN paciente p ON a.paciente_id = p.paciente_id
      LEFT JOIN profissional prof ON a.profissional_id = prof.profissional_id
      ORDER BY a.data_agendamento, a.hora_agendamento
    `;
    db.query(query, callback);
  }

  static visualizarPorId(id, callback) {
    const query = `
      SELECT 
        a.agendamento_id,
        a.paciente_id,
        p.nome_completo AS paciente_nome,
        a.profissional_id,
        prof.nome_completo AS profissional_nome,
        a.data_agendamento,
        a.hora_agendamento,
        a.tipo_agendamento,
        a.observacoes
      FROM agendamento a
      LEFT JOIN paciente p ON a.paciente_id = p.paciente_id
      LEFT JOIN profissional prof ON a.profissional_id = prof.profissional_id
      WHERE a.agendamento_id = ?
    `;
    db.query(query, [id], callback);
  }

  static editar(id, dados, callback) {
  // Campos fixos do banco que podem ser atualizados
  const camposPermitidos = [
    'paciente_id',
    'profissional_id',
    'data_agendamento',
    'hora_agendamento',
    'tipo_agendamento',
    'observacoes'
  ];

  const fields = [];
  const values = [];

  // Apenas pega os campos que vieram no objeto dados
  camposPermitidos.forEach(campo => {
    if (dados[campo] !== undefined && dados[campo] !== null) {
      fields.push(`${campo} = ?`);
      values.push(dados[campo]);
    }
  });

  if (fields.length === 0) {
    return callback(new Error('Nenhum campo válido para atualizar.'));
  }

  const query = `UPDATE agendamento SET ${fields.join(', ')} WHERE agendamento_id = ?`;
  values.push(id);

  console.log('Query de atualização:', query);
  console.log('Valores:', values);

  db.query(query, values, callback);
}


  static deletar(id, callback) {
    const query = `DELETE FROM agendamento WHERE agendamento_id = ?`;
    db.query(query, [id], callback);
  }
}

export default Agendamento;